from pydantic_settings import BaseSettings


class MachingConfig(BaseSettings):
    MODEL_NAME: str = "mistral_embed_8:latest"


matching_config = MachingConfig()
