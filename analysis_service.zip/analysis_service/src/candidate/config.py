import os

from pydantic_settings import BaseSettings


class CandidateConfig(BaseSettings):
    MODEL_NAME: str = "mistral_embed_8:latest"
    CV_UPLOAD_DIR: str = "./candidate_cv/"
    LOCAL_SERVER_URL: str = "http://10.1.1.101:10002/"  # Example URL of your local Ollama server


candidate_config = CandidateConfig()



