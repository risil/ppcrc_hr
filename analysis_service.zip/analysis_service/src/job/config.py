from pydantic_settings import BaseSettings


class JobConfig(BaseSettings):
    MODEL_NAME: str = "mistral_embed_8:latest"


job_config = JobConfig()
